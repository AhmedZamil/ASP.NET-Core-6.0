﻿using Marielinas.ASP.NET6._0.Repository;

namespace Marielinas.ASP.NET6._0.ViewModel
{
    public class ShoppingCartViewModel
    {
        public ShoppingCart ShoppingCart { get; set; }
        public decimal ShoppingCartTotal { get; set; }
    }
}
